Question number 5

package org.com.Capgemini2;


import java.util.ArrayList;
import java.util.List;

public class FirstLetterOfEachWordString {
	public static void main(String[] args) {
		List<String> array = new ArrayList<String>();
		array.add("Mahesh");
		array.add("Chotu");
		array.add("Harish");
		array.add("Kanna");
		System.out.println("Names :\n"+array);
		String result = array.stream().map(Mahesh -> Character.toString(Mahesh.charAt(0))).reduce(" ", (a, b) -> a + b);
		System.out.println(result);
	
	}
}