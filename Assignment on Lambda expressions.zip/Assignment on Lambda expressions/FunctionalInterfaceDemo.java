Question number 3

package org.com.Capgemini2;


import java.util.function.*;

public class FunctionalInterfaceDemo 
{
	public static void main(String args[])
	{
		Predicate<Integer> predicate=(a)->a>10;
		boolean result1=predicate.test(52);
		System.out.println("Greater than 10 ="+result1);
		
		boolean result2=predicate.test(6);
		System.out.println("Greater than 10 ="+result2);
		
		Supplier<String> supplier=()->{return "Mahesh";};
		String s=supplier.get();
		System.out.println("The string is "+s);
		
		Function<String,Integer> length=(str)->str.length();
		String str="Podendla Mahesh Yadav";
		System.out.println("Length of string = "+length.apply(str));
		
		
	}
}
