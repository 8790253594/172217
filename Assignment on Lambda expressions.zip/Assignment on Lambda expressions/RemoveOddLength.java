Question number 4

package org.com.Capgemini2;

import java.util.ArrayList;
import java.util.List;

public class RemoveOddLength {

	public static void main(String[] args) {
		
		List<String> array = new ArrayList<String>();
		array.add("Odd");
		array.add("Even");
		array.add("Mahesh");
		array.add("Odd");
		System.out.println("Names :\n"+array);
		System.out.println("**********************************");
		
		array.removeIf(e -> e.length() % 2 != 0);
		array.forEach(System.out::println);
	}
}