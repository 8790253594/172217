package org.com.Capgemini2;

@FunctionalInterface
public interface MyInterfaceOrders {
	
	void Order(double amount);
}