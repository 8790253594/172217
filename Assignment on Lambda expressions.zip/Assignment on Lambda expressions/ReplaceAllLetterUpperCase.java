Question number 6

package org.com.Capgemini2;

import java.util.ArrayList;
import java.util.List;

public class ReplaceAllLetterUpperCase {
	public static void main(String[] args) {
		List<String> array = new ArrayList<String>();
		array.add("mahesh");
		array.add("manu");
		array.add("harish");
		array.add("chotu");
		System.out.println("Names :\n"+array);
		array.replaceAll(e -> e.toUpperCase());
		array.forEach(System.out::println);
	}

}



