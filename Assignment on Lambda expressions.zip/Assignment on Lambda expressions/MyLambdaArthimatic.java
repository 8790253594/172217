Question number 1


package org.com.Capgemini2;


@FunctionalInterface
public interface MyInterfaceArthimatic {
	
	public abstract void arthimatic(int m, int n);
	

}


************************************Main **************************************************
package org.com.Capgemini2;

public class MyLambdaArthimatic {

	public static void main(String[] args) {
		MyInterfaceArthimatic s = (m,n) -> 
		{
			System.out.println(m+n);
			System.out.println(m-n);
			System.out.println(m*n);
			System.out.println(m/n);
		};
		s.arthimatic(10, 5);
	}
}
