Question number 2
package org.com.Capgemini2;

@FunctionalInterface
public interface MyInterfaceOrders {
	
	void Order(double amount);
}


***********************************Main****************************
package org.com.Capgemini2;

public class OrderImplementation {

	public static void main(String[] args) {
		MyInterfaceOrders s = (amount) -> 
		{
			if(amount<10000)
				System.out.println("Accepted");
			else
				System.out.println("Completed");
		};
		s.Order(122223);
}
}
