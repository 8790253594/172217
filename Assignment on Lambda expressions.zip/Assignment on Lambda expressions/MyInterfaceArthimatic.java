package org.com.Capgemini2;


@FunctionalInterface
public interface MyInterfaceArthimatic {
	
	public abstract void arthimatic(int m, int n);
	

}