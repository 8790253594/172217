package org.com.Capgemini;
//Assignment question number 8, 13,14,15 on Streams

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class Class {
	public static void main(String args[]) {
		List<Transaction> al=new ArrayList<>();
al.add(new Transaction(new Trader("manu", "Singapore"), 2011, 1000));
al.add(new Transaction(new Trader("manu1", "Indore"), 2014, 10080));	
al.add(new Transaction(new Trader("Mahesh", "Pune"), 2041, 10400));
al.add(new Transaction(new Trader("harish", "Hydernagar"), 2001, 10050));
al.add(new Transaction(new Trader("kanna", "Pune"), 2008, 10060));
al.add(new Transaction(new Trader("manu3", "Pune"), 2019, 10700));
al.add(new Transaction(new Trader("madnu", "Delhi"), 2017, 5000));
al.add(new Transaction(new Trader("manur", "Pune"), 2015, 8000));
al.add(new Transaction(new Trader("manus", "Bangalore"), 2014, 9000));
al.add(new Transaction(new Trader("manuss", "Hyderabad"), 2013, 2000));
List<Transaction> names8=al.stream()
                   .filter(p->p.getTrader().getCity()=="Delhi")
					.collect(Collectors.toList());
            names8.forEach(e->System.out.println("Assignment 13            transaction: "+e.getValue()+" by "+e.getTrader().getName()));

           Transaction max=al.stream()
            		.max((p1,p2)->Integer.compare(p1.getValue(), p2.getValue()))
            				.get();
             System.out.println("Assignment 14 = "+  max.getValue());
             Transaction min=al.stream()
             		.min((p1,p2)->Integer.compare(p1.getValue(), p2.getValue()))
             				.get();
              System.out.println("Assignment 15 ="+ min.getValue());
              
//              List<Transaction> list5=al.stream()
//            		  .filter(p->p.getYear()==2011)
//              		.max(Comparator.comparing(Transaction::getValue))
//              		.collect(Collectors.toList());
//             System.out.println("Assignment 8="+list5);              
	}

}
