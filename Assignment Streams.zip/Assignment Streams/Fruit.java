package org.com.Capgemini;

public class Fruit {
 String name;
 int Calories;
 public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getCalories() {
	return Calories;
}
public void setCalories(int calories) {
	Calories = calories;
}
public int getPrice() {
	return Price;
}
public void setPrice(int price) {
	Price = price;
}
public String getColor() {
	return color;
}
public void setColor(String color) {
	this.color = color;
}
int Price;
 String color;
public Fruit(String name, int calories, int price, String color) {
	super();
	this.name = name;
	Calories = calories;
	Price = price;
	this.color = color;
}
public Fruit() {
	super();
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "Fruit [name=" + name + ", Calories=" + Calories + ", Price=" + Price + ", color=" + color + "]";
}

}
