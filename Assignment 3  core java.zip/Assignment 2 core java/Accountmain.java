package org.com.Capgemini1;



public class Accountmain {

	public static void main(String args[])
	{
	
		
		 
		 SavingsAccount sa1=  new SavingsAccount(1000, 103 , "Manu", "Yes", 100);
		 SavingsAccount sa2=new SavingsAccount(100, 102 , "ram", "Yes", 10);
		 SavingsAccount sa3=new SavingsAccount(10000, 104 , "mahesh", "Yes", 1000);
		
			BankAccountlist ba=new BankAccountlist();
			ba.addAccountDetails(sa1);
			ba.addAccountDetails(sa2);
			ba.addAccountDetails(sa3);
			
			 for(SavingsAccount s:ba.getAllDetails())
			 {
				 System.out.println(s);
			 }
	}
}
