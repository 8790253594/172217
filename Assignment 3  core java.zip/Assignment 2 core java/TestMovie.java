package org.com.Capgemini2;



public class TestMovie {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Movie_DetailList mdl=new Movie_DetailList();
		Movie_Details md=new Movie_Details("Mahesh","Hrithik","Trisha","Love");
		Movie_Details md1=new Movie_Details("Darling","Prabhas","Anuskha","Romantic");
		Movie_Details md2=new Movie_Details("Darling1","Arabhas","Trisha","Horror");
		mdl.Add_movie(md);
		mdl.Add_movie(md1);
		mdl.Add_movie(md2);
	
		for(Movie_Details dm:mdl.Sort("Genre"))
	      {			
			System.out.println(dm);	
          }
           //**** sort by movie name*****//
          mdl.find_movie_By_mov_name("Mahesh");
          //****Sort by Genre***//
           mdl.find_movie_By_Genre("Love");
           
	}

}
