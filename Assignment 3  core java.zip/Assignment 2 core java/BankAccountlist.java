package org.com.Capgemini1;


import java.util.TreeSet;

public class BankAccountlist {

	
	 TreeSet<SavingsAccount> ts = new TreeSet<SavingsAccount>();	 
	 
		  
		 public void addAccountDetails(SavingsAccount acc) {
			 ts.add(acc);
		 }	 
		public  TreeSet<SavingsAccount> getAllDetails()
		{
			return  ts;
		}
	 
}
