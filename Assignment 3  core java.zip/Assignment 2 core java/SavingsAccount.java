package org.com.Capgemini1;

public class SavingsAccount implements Comparable<SavingsAccount>{
	double Acc_bal;
	int acc_ID;
	String accountHoldername;
	String IsSalaryAccount;
	double amount;
	public SavingsAccount(double acc_bal, int acc_ID, String accountHoldername, String isSalaryAccount, double amount) {
		super();
		Acc_bal = acc_bal;
		this.acc_ID = acc_ID;
		this.accountHoldername = accountHoldername;
		IsSalaryAccount = isSalaryAccount;
		this.amount = amount;
	}
	public SavingsAccount() {
		super();
	}
	public double getAcc_bal() {
		return Acc_bal;
	}
	public void setAcc_bal(double acc_bal) {
		Acc_bal = acc_bal;
	}
	public int getAcc_ID() {
		return acc_ID;
	}
	public void setAcc_ID(int acc_ID) {
		this.acc_ID = acc_ID;
	}
	
	public String getAccountHoldername() {
		return accountHoldername;
	}
	public void setAccountHoldername(String accountHoldername) {
		this.accountHoldername = accountHoldername;
	}
	public String getIsSalaryAccount() {
		return IsSalaryAccount;
	}
	public void setIsSalaryAccount(String isSalaryAccount) {
		IsSalaryAccount = isSalaryAccount;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount)
	{
		this.amount = amount;
	}
	
	public double withdraw() {
		if(amount >=Acc_bal)
		{
			return  Acc_bal=Acc_bal-amount;
		}
		else
			return Acc_bal;
		
	}
	public double deposit() 
	{
	       return amount+Acc_bal;
	}
	@Override
	public String toString() {
		return "SavingsAccount [Acc_bal=" + Acc_bal + ", acc_ID=" + acc_ID + ", accountHoldername=" + accountHoldername
				+ ", IsSalaryAccount=" + IsSalaryAccount + "]";
	}
	@Override
	public int compareTo(SavingsAccount ss) {
		// TODO Auto-generated method stub
		
		return (this.getAcc_ID()-ss.getAcc_ID());
		
		
	}
	
}
