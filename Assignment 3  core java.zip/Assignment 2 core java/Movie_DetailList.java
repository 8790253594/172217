package org.com.Capgemini2;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Movie_DetailList {

	ArrayList<Movie_Details> al = new ArrayList<>();
	public void Add_movie( Movie_Details md) {
		al.add(md);
		
	    }
	public ArrayList<Movie_Details> getAllMovieList() {
		return al;
		}	
	public void remove(String s)
	{
		for(Movie_Details m:al)
		{
			if(s.equals(m.mov_name))
			{
				al.remove(m);
		
			}
			System.out.println(al);
		}
		
	}
	public void removeall(String s1)
	{
		for(Movie_Details m:al)
		{
			if(s1.equals(m.mov_name)) {
				al.removeAll(al);
			}
			System.out.println(m);
		}
	}
	public void find_movie_By_mov_name(String s1)
	{
		for(Movie_Details m:al)
		{
			if(s1.equals(m.mov_name)) {
				System.out.println(m);
			}
			
		}
	}
	public void find_movie_By_Genre(String s1)
	{
		for(Movie_Details m:al)
		{
			if(s1.equals(m.Genre)) {
				System.out.println(m);
			}
			
		}
	}
	public List<Movie_Details> Sort(String Type){
		if(Type=="Actorname")
		{
			
	Collections.sort(al, new Comparator<Movie_Details>() {

			@Override
			public int compare(Movie_Details o1, Movie_Details o2) {
				// TODO Auto-generated method stub
				return o1.getLead_actor().compareTo(o2.getLead_actor());
			}
		});

		}
		else if(Type=="Genre")
		{
			
	Collections.sort(al, new Comparator<Movie_Details>() {

			@Override
			public int compare(Movie_Details o1, Movie_Details o2) {
				// TODO Auto-generated method stub
				return o1.getGenre().compareTo(o2.getGenre());
			}
		});

		}
			return al;
		}
	
	}
	
	

